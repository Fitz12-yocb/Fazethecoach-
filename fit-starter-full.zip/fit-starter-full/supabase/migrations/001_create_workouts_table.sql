-- Supabase / Postgres migration to create workouts table
CREATE TABLE IF NOT EXISTS public.workouts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  duration_minutes integer,
  level text,
  tags text[],
  thumbnail_url text,
  video_url text,
  instructor_id uuid,
  created_at timestamptz DEFAULT now()
);

-- index for faster slug lookup
CREATE INDEX IF NOT EXISTS idx_workouts_slug ON public.workouts (slug);
