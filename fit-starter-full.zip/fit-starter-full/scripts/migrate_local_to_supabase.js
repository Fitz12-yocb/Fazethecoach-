/**
 * Script to migrate data/workouts.json into Supabase.
 * Usage: node scripts/migrate_local_to_supabase.js
 * Requires SUPABASE_SERVICE_ROLE_KEY and SUPABASE_URL env
 */
const fs = require('fs');
const { createClient } = require('@supabase/supabase-js');

async function main(){
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) {
    console.error('Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY');
    process.exit(1);
  }
  const supabase = createClient(url, key);
  const data = JSON.parse(fs.readFileSync('data/workouts.json','utf8'));
  for (const w of data.workouts){
    const { error } = await supabase.from('workouts').insert([{
      title: w.title,
      slug: w.slug,
      description: w.description,
      duration_minutes: w.duration_minutes,
      level: w.level,
      tags: w.tags,
      thumbnail_url: w.thumbnail_url,
      video_url: w.video_url
    }]);
    if (error) console.error('error', error);
    else console.log('imported', w.slug);
  }
  console.log('Done');
}
main();
