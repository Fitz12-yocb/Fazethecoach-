import useSWR from 'swr';
import Layout from '../components/Layout';
import VideoCard from '../components/VideoCard';

const fetcher = (url) => fetch(url).then(r=>r.json());

export default function Home() {
  const {data, error} = useSWR('/api/workouts', fetcher);

  return (
    <Layout>
      <section>
        <h1 style={{fontSize:28}}>Workout Library</h1>
        <p style={{color:'#6b7280'}}>Browse workouts — filter and save to your profile (MVP).</p>

        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))',gap:16,marginTop:18}}>
          {data?.workouts?.map(w => <VideoCard key={w.id} w={w} />)}
          {!data && <div>Loading...</div>}
        </div>
      </section>
    </Layout>
  );
}
