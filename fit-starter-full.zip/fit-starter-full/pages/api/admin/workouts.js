/**
 * Admin API using Supabase service_role key.
 * ENV required:
 * SUPABASE_URL
 * SUPABASE_SERVICE_ROLE_KEY  (server-only, do NOT expose in client)
 *
 * Note: For production, protect this route with authentication/authorization.
 */
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY; // server-only
const supabase = createClient(supabaseUrl, supabaseKey);

export default async function handler(req, res) {
  if (!supabaseUrl || !supabaseKey) {
    return res.status(500).json({ error: 'Supabase not configured' });
  }

  if (req.method === 'GET') {
    const { data, error } = await supabase.from('workouts').select('*').order('created_at', { ascending: false }).limit(500);
    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json({ workouts: data });
  }

  if (req.method === 'POST') {
    const body = req.body;
    const newItem = {
      title: body.title || 'Untitled',
      slug: body.slug || ('w-' + Date.now()),
      description: body.description || '',
      duration_minutes: body.duration_minutes || 10,
      level: body.level || 'beginner',
      tags: body.tags || [],
      thumbnail_url: body.thumbnail_url || '',
      video_url: body.video_url || '',
    };
    const { data, error } = await supabase.from('workouts').insert([newItem]).select().single();
    if (error) return res.status(500).json({ error: error.message });
    return res.status(201).json({ ok: true, workout: data });
  }

  return res.status(405).json({ error: 'Method not allowed' });
}
