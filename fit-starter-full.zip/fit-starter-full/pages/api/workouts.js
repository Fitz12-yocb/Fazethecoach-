import { createClient } from '@supabase/supabase-js';

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY);

export default async function handler(req, res) {
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_ANON_KEY) {
    return res.status(500).json({error:'Supabase not configured'});
  }
  const { data, error } = await supabase.from('workouts').select('*').order('created_at', { ascending:false }).limit(500);
  if (error) return res.status(500).json({error: error.message});
  res.status(200).json({workouts: data});
}
