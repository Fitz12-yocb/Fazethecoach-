import {useRouter} from 'next/router';
import useSWR from 'swr';
import ReactPlayer from 'react-player';
import Layout from '../../components/Layout';

const fetcher = (url) => fetch(url).then(r=>r.json());

export default function WorkoutPage() {
  const router = useRouter();
  const { slug } = router.query;
  const { data } = useSWR(() => slug ? `/api/workouts/${slug}` : null, fetcher);

  if (!data) return <Layout><div>Loading...</div></Layout>;
  const w = data.workout;

  return (
    <Layout>
      <h1 style={{fontSize:22}}>{w.title}</h1>
      <div style={{marginTop:12, maxWidth:900}}>
        <ReactPlayer url={w.video_url} controls width="100%" height="480px"/>
      </div>

      <div style={{marginTop:18}}>
        <p>{w.description}</p>
        <div style={{color:'#6b7280'}}>Tags: {w.tags?.join(', ')}</div>
      </div>
    </Layout>
  );
}
