import {useState} from 'react';
import {useRouter} from 'next/router';
import Layout from '../../components/Layout';

export default function NewWorkout() {
  const [title, setTitle] = useState('');
  const [slug, setSlug] = useState('');
  const [duration, setDuration] = useState(10);
  const [level, setLevel] = useState('beginner');
  const [videoUrl, setVideoUrl] = useState('');
  const router = useRouter();

  async function handleSubmit(e){ 
    e.preventDefault();
    const res = await fetch('/api/admin/workouts', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        title, slug, duration_minutes: Number(duration), level, video_url: videoUrl
      })
    });
    if (res.ok) router.push('/admin');
    else alert('Error creating');
  }

  return (
    <Layout>
      <h1>Create workout</h1>
      <form onSubmit={handleSubmit} style={{maxWidth:700}}>
        <label>Title<br/><input value={title} onChange={e=>setTitle(e.target.value)} required style={{width:'100%'}}/></label>
        <br/><br/>
        <label>Slug (unique)<br/><input value={slug} onChange={e=>setSlug(e.target.value)} required style={{width:'100%'}}/></label>
        <br/><br/>
        <label>Duration minutes<br/><input type="number" value={duration} onChange={e=>setDuration(e.target.value)} style={{width:120}}/></label>
        <br/><br/>
        <label>Level<br/>
          <select value={level} onChange={e=>setLevel(e.target.value)}>
            <option value="beginner">Beginner</option>
            <option value="intermediate">Intermediate</option>
            <option value="advanced">Advanced</option>
          </select>
        </label>
        <br/><br/>
        <label>Video URL (mp4 or HLS)<br/><input value={videoUrl} onChange={e=>setVideoUrl(e.target.value)} style={{width:'100%'}}/></label>
        <br/><br/>
        <button type="submit" style={{padding:'10px 14px',background:'#0ea5a4',color:'#fff',borderRadius:6}}>Create</button>
      </form>
    </Layout>
  );
}
