import useSWR from 'swr';
import Link from 'next/link';
import Layout from '../../components/Layout';

const fetcher = (url) => fetch(url).then(r=>r.json());

export default function Admin() {
  const {data, mutate} = useSWR('/api/admin/workouts', fetcher);

  if (!data) return <Layout><div>Loading admin...</div></Layout>;

  return (
    <Layout>
      <h1>Admin — Workouts</h1>
      <p><Link href="/admin/new"><a style={{background:'#0ea5a4',color:'#fff',padding:'8px 10px',borderRadius:6}}>Create new workout</a></Link></p>

      <table style={{width:'100%',borderCollapse:'collapse',marginTop:12}}>
        <thead>
          <tr style={{textAlign:'left',borderBottom:'1px solid #e5e7eb'}}>
            <th>ID</th><th>Title</th><th>Duration</th><th>Level</th>
          </tr>
        </thead>
        <tbody>
          {data.workouts.map(w => (
            <tr key={w.id} style={{borderBottom:'1px solid #f3f4f6'}}>
              <td style={{padding:8}}>{w.slug}</td>
              <td style={{padding:8}}>{w.title}</td>
              <td style={{padding:8}}>{w.duration_minutes} min</td>
              <td style={{padding:8}}>{w.level}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </Layout>
  );
}
