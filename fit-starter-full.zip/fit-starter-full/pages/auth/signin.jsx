import { useState } from 'react';
import { supabase } from '../../lib/supabaseClient';
import Layout from '../../components/Layout';

export default function SignIn() {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  async function handleMagicLink(e) {
    e.preventDefault();
    setMessage('Sending magic link...');
    const { error } = await supabase.auth.signInWithOtp({ email });
    if (error) {
      setMessage('Error: ' + error.message);
    } else {
      setMessage('Magic link sent. Check your email.');
    }
  }

  return (
    <Layout>
      <h1>Sign in</h1>
      <p>Enter your email and we will send a magic sign-in link.</p>
      <form onSubmit={handleMagicLink}>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@domain.com" style={{width:320,padding:8}}/>
        <br/><br/>
        <button style={{padding:'8px 12px',background:'#0ea5a4',color:'#fff',borderRadius:6}}>Send magic link</button>
      </form>
      <p style={{marginTop:12}}>{message}</p>
    </Layout>
  );
}
