import Layout from '../components/Layout';

export default function Pricing() {
  return (
    <Layout>
      <h1>Pricing</h1>
      <p>Sample pricing page. Integrate Stripe Checkout to sell subscriptions and one-time program products.</p>
    </Layout>
  );
}
