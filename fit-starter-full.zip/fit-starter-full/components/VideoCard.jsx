import Link from 'next/link';

export default function VideoCard({w}) {
  return (
    <div style={{background:'#fff',borderRadius:6,overflow:'hidden',boxShadow:'0 1px 3px rgba(0,0,0,0.08)'}}>
      <div style={{height:180,overflow:'hidden'}}>
        <img src={w.thumbnail_url||'/placeholder.jpg'} alt={w.title} style={{width:'100%',objectFit:'cover'}}/>
      </div>
      <div style={{padding:12}}>
        <h3 style={{margin:0,fontSize:16}}>{w.title}</h3>
        <p style={{margin:'6px 0',color:'#6b7280'}}>{w.duration_minutes} min • {w.level}</p>
        <Link href={`/workout/${w.slug}`}><a style={{display:'inline-block',marginTop:8,padding:'8px 12px',background:'#0ea5a4',color:'#fff',borderRadius:6}}>Open</a></Link>
      </div>
    </div>
  );
}
