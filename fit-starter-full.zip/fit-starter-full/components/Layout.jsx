import Link from 'next/link';

export default function Layout({children}) {
  return (
    <div>
      <header style={{background:'#fff',borderBottom:'1px solid #e5e7eb'}}>
        <div className="container" style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'14px 20px'}}>
          <div>
            <Link href="/"><a style={{fontWeight:700,fontSize:18}}>Fit Starter</a></Link>
          </div>
          <nav>
            <Link href="/"><a style={{marginRight:12}}>Home</a></Link>
            <Link href="/pricing"><a style={{marginRight:12}}>Pricing</a></Link>
            <Link href="/admin"><a>Admin</a></Link>
          </nav>
        </div>
      </header>

      <main className="container" style={{paddingTop:20}}>
        {children}
      </main>
    </div>
  );
}
